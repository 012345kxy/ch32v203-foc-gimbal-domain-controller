/*
 * usart_control.h
 *
 *  Created on: 2025��7��2��
 *      Author: 17485
 */

#ifndef USER_USART_CONTROL_H_
#define USER_USART_CONTROL_H_

void USART3_Init(void);
void USART3_IRQHandler(void);

extern float target;


#endif /* USER_USART_CONTROL_H_ */
