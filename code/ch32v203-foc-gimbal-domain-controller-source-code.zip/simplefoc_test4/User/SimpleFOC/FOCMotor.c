/*
 * FOCMotor.c
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#include "MyProject.h"


/******************************************************************************/
float shaft_angle=0;//!< current motor angle
float electrical_angle=0;
float shaft_velocity=0;
float current_sp=0;
float shaft_velocity_sp=0;
float shaft_angle_sp=0;
DQVoltage_s voltage;
DQCurrent_s current;

TorqueControlType torque_controller;
MotionControlType controller;

float sensor_offset=0;
float zero_electric_angle=0;
/******************************************************************************/
// shaft angle calculation ת�ӽǶȼ���
float shaftAngle(void)
{
  // if no sensor linked return previous value ( for open loop )
  //if(!sensor) return shaft_angle;
  return sensor_direction*getAngle() - sensor_offset;
}
// shaft velocity calculation ת���ٶȼ���
float shaftVelocity(void)
{
  // if no sensor linked return previous value ( for open loop ) ���û�д��������ӷ���ǰһ��ֵ(���ڿ���)
  //if(!sensor) return shaft_velocity;
  return sensor_direction*LPF_velocity(getVelocity());
}
/******************************************************************************/
float electricalAngle(void)//��Ƕȼ���
{
  return _normalizeAngle((shaft_angle + sensor_offset) * pole_pairs - zero_electric_angle);
}
/******************************************************************************/

