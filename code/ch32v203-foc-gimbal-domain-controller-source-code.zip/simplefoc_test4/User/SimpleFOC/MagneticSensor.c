/*
 * MagnaticSensor.c
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#include "MyProject.h"
#include "ch32v20x.h"
#include "MagneticSensor.h"
/******************************************************************************/
long  cpr=0;//λ�ô�����������
float full_rotation_offset=0;//ȫ��תƫ����
long  angle_data_prev=0;//��һʱ�̶�ȡ���ı�����ֵ
unsigned long velocity_calc_timestamp=0;//�����ٶȼ������һʱ��ʱ��
float angle_prev=0;//��һʱ�̵ĽǶ�ֵ
uint16_t Ack_debug=0;
float angle_data_debug=0;
/******************************************************************************/

/******************************************************************************/
#define  AS5600_Address  0x36
#define  RAW_Angle_Hi    0x0C   //V2.1.1 bugfix
#define  RAW_Angle_Lo    0x0D
#define  AS5600_CPR      4096
/******************************************************************************/
void __nop(void);
void AS5600_WriteRag(uint8_t RagAddress, uint8_t Data)
{
    I2C_Start();
    I2C_SendByte(AS5600_Address);
    I2C_ReceiveAck();
    I2C_SendByte(RagAddress);
    I2C_ReceiveAck();
    I2C_SendByte(Data);
    I2C_ReceiveAck();
    I2C_Stop();
}
uint8_t AS5600_ReadRag(uint8_t RagAddress)
{
    uint8_t Data=0 ;
    I2C_Start();
    I2C_SendByte(AS5600_Address);
    I2C_ReceiveAck();
    I2C_SendByte(RagAddress);
    I2C_ReceiveAck();

    I2C_Start();
    I2C_SendByte(((uint8_t)AS5600_Address<<1)|0x01);
//    I2C_SendByte(AS5600_Address|0x01);
    Data= I2C_ReceiveByte();
    I2C_SendAck(1);
    I2C_Stop();
    return Data;
}
//uint16_t I2C_getRawCount(void)
//{
//    uint8_t dh, dl;
//
//        // ��ȡ���ֽڣ�RAW_Angle_Hi��
//        dh = AS5600_ReadRag(RAW_Angle_Hi);
//
//        // ��ȡ���ֽڣ�RAW_Angle_Lo��
//        dl = AS5600_ReadRag(RAW_Angle_Lo);
//
//        // ���Ϊ16λ���ݣ�0x0C��0x0D��12λ��Ч�����ֽ�����8λ������ֽڰ�λ��
//        return (uint16_t)( (dh << 8) | dl );
//}
/******************************************************************************/



/******************************************************************************/
//TLE5012B
#define READ_ANGLE_VALUE  0x8020
#define TLE5012B_CPR      32768
/******************************************************************************/
#define SPI2_CS1_L  GPIO_ResetBits(GPIOB, GPIO_Pin_8)      //CS1_L
#define SPI2_CS1_H  GPIO_SetBits(GPIOB, GPIO_Pin_8)        //CS1_H

#define SPI2_TX_OFF {GPIOB->CFGHR&=0x0FFFFFFF;GPIOB->CFGHR|=0x40000000;}  //��PB15(MOSI)����Ϊ��������ģʽ
#define SPI2_TX_ON  {GPIOB->CFGHR&=0x0FFFFFFF;GPIOB->CFGHR|=0xB0000000;}  //��PB15(MOSI)�����������(50MHz)
/******************************************************************************/
unsigned short SPIx_ReadWriteByte(unsigned short byte)
{
    unsigned short retry = 0;

    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET)
    {
        if(++retry>200)return 0;
    }
    SPI_I2S_SendData(SPI2, byte);
    retry = 0;
    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET)
    {
        if(++retry>200)return 0;
    }
    return SPI_I2S_ReceiveData(SPI2);
}
/******************************************************************************/
unsigned short ReadTLE5012B_1(unsigned short Comm)
{
    unsigned short u16Data=0;

    SPI2_CS1_L;
    SPIx_ReadWriteByte(Comm);
    SPI2_TX_OFF;
    __nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();  //Twr_delay=130ns min
    u16Data = SPIx_ReadWriteByte(0xffff);

    SPI2_CS1_H;
    SPI2_TX_ON;
    return(u16Data);
}
/******************************************************************************/
//#endif

/******************************************************************************/
void MagneticSensor_Init(void)
{
#if M1_AS5600
    cpr=AS5600_CPR;
    angle_data_prev = AS5600_ReadTwoByte(_raw_ang_hi, _raw_ang_lo);
//    printf("pre is %lf\r\n",angle_data_prev);
#elif M1_TLE5012B
    cpr=TLE5012B_CPR;
    angle_data_prev = ReadTLE5012B_1(READ_ANGLE_VALUE)&0x7FFF;
#endif

    full_rotation_offset = 0;
    velocity_calc_timestamp=0;
}
/******************************************************************************/
//int test[100]={0};
//int iii=0;

float getAngle(void)
{
    float angle_data=0,d_angle=0;

#if M1_AS5600
    angle_data = AS5600_ReadTwoByte(_raw_ang_hi, _raw_ang_lo);
//    if(iii<99)
//    {
//        test[iii]=angle_data;
//        iii++;
//    }
//    if(angle_data > 4096)
//    {
//        int uuu=0;
//        uuu++;
//    }

    angle_data_debug = angle_data;
#elif M1_TLE5012B
    angle_data = ReadTLE5012B_1(READ_ANGLE_VALUE)&0x7FFF;
#endif

    // tracking the number of rotations ������ת����
    // in order to expand angle range form [0,2PI] to basically infinity �Ա㽫�Ƕȷ�Χ��[0,2 pi]��չ�����������
    d_angle = angle_data - angle_data_prev;//����Ƕȱ仯��
    // if overflow happened track it as full rotation ������������������Ϊ��ȫ��ת
    //fabs()������˫���ȸ������ľ���ֵ
    if(fabs(d_angle) > (0.8*cpr) )
    {
        full_rotation_offset += d_angle > 0 ? -_2PI : _2PI;
    } //
    // save the current angle value for the next steps ���浱ǰ�ĽǶ�ֵ�Թ���һ��ʹ��
    // in order to know if overflow happened �Ա��˽��Ƿ������
    angle_data_prev = angle_data;
    // return the full angle ����ȫ�Ƕ�
    // (number of full rotations)*2PI + current sensor angle (ȫ��ת����)*2PI +�����������Ƕ�
    // cprΪ�����������̣�4096��
    return  (full_rotation_offset + ( angle_data / (float)cpr) * _2PI) ;

}
/******************************************************************************/
// Shaft velocity calculation ����ű����ٶ�
float getVelocity(void)
{
    unsigned long now_us=0;
    float Ts=0, angle_c=0, vel=0;

    // calculate sample time ������ʱ��
    now_us = SysTick->CNT; //_micros();
    if(now_us<velocity_calc_timestamp)Ts = (float)(velocity_calc_timestamp - now_us)/9*1e-6;//9Mhz/9=1Mhz����λs
    else
        Ts = (float)(0xFFFFFF - now_us + velocity_calc_timestamp)/9*1e-6;
    // quick fix for strange cases (micros overflow) �����޸���ֵ����(micros���)
    if(Ts == 0 || Ts > 0.5) Ts = 1e-3;

    // current angle ��ǰ�Ƕ�
    angle_c = getAngle();
    // velocity calculation �ٶȼ���
    vel = (angle_c - angle_prev)/Ts;

    // save variables for future pass ����ǶȺ�ʱ��
    angle_prev = angle_c;
    velocity_calc_timestamp = now_us;
    return vel;
}
/******************************************************************************/
