/*
 * lowpass_filter.h
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#ifndef USER_SIMPLEFOC_LOWPASS_FILTER_H_
#define USER_SIMPLEFOC_LOWPASS_FILTER_H_

/******************************************************************************/
float LPF_velocity(float x);
/******************************************************************************/

#endif /* USER_SIMPLEFOC_LOWPASS_FILTER_H_ */
