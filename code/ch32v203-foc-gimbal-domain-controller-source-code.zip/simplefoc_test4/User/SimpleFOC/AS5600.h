/*
 * AS5600.h
 *
 *  Created on: May 20, 2025
 *      Author: 17485
 */

#ifndef USER_AS5600_AS5600_H_
#define USER_AS5600_AS5600_H_

#include "./hardware/Software_I2C.h"

#define _raw_ang_hi 0x0c
#define _raw_ang_lo 0x0d

u8 AS5600_ReadOneByte(u16 ReadAddr);
void AS5600_WriteOneByte(u16 WriteAddr,u8 WriteData);
float AS5600_ReadTwoByte(u16 ReadAddr_hi,u16 ReadAddr_lo);


#endif /* USER_AS5600_AS5600_H_ */
