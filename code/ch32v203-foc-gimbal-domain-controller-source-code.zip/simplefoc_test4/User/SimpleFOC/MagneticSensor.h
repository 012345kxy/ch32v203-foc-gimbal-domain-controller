/*
 * MagnaticSensor.h
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#ifndef USER_SIMPLEFOC_MAGNETICSENSOR_H_
#define USER_SIMPLEFOC_MAGNETICSENSOR_H_

/******************************************************************************/
extern long  cpr;
extern float full_rotation_offset;
extern long  angle_data_prev;
extern unsigned long velocity_calc_timestamp;
extern float angle_prev;
extern float angle_data_debug;
extern uint16_t Ack_debug;
extern long sensor_direction;
/******************************************************************************/
void MagneticSensor_Init(void);
float getAngle(void);
float getVelocity(void);
uint16_t I2C_getRawCount(void);
/******************************************************************************/

#endif /* USER_SIMPLEFOC_MAGNETICSENSOR_H_ */
