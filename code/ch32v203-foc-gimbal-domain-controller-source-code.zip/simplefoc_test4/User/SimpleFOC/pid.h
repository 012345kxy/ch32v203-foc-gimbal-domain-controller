/*
 * pid.h
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#ifndef USER_SIMPLEFOC_PID_H_
#define USER_SIMPLEFOC_PID_H_

/******************************************************************************/
void PID_init(void);
float PID_velocity(float error);
float PID_angle(float error);
/******************************************************************************/

#endif /* USER_SIMPLEFOC_PID_H_ */
