/*
 * MyProject.h
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#ifndef USER_MYPROJECT_H_
#define USER_MYPROJECT_H_

/* Includes ------------------------------------------------------------------*/

#include "ch32v20x.h"
#include "./hardware/usart.h"
#include "usart_control.h"
#include "./hardware/delay.h"
#include "./hardware/timer.h"
#include "./hardware/iic.h"
#include "./hardware/spi2.h"

#include "./SimpleFOC/MagneticSensor.h"
#include "./SimpleFOC/foc_utils.h"
#include "./SimpleFOC/FOCMotor.h"
#include "./SimpleFOC/BLDCmotor.h"
#include "./SimpleFOC/lowpass_filter.h"
#include "./SimpleFOC/pid.h"
#include "./hardware/Software_I2C.h"
#include "./SimpleFOC/AS5600.h"

/******************************************************************************/
#define M1_Enable    GPIO_SetBits(GPIOB,GPIO_Pin_14);          //�ߵ�ƽʹ��
#define M1_Disable   GPIO_ResetBits(GPIOB,GPIO_Pin_14);        //�͵�ƽʧ��
/******************************************************************************/
//���������ͣ�����ֻ��ѡһ
#define M1_AS5600    1
#define M1_TLE5012B  0
/******************************************************************************/

#endif /* USER_MYPROJECT_H_ */
