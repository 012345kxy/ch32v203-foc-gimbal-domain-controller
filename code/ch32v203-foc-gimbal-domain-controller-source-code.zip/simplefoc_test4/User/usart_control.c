

#include "ch32v20x.h"
#include "usart_control.h"
#include "ch32v20x.h"

// —— 配置参数 —————————————————————
#define PACKET_BYTES   18    // 9×2
#define ELEMENTS       9     // uint16_t 元素数

// —— 全局缓冲 —————————————————————
static uint8_t  rx_buf[PACKET_BYTES];
static uint8_t  rx_count = 0;
static uint16_t packet[ELEMENTS];
float target=0;


// —— Helper：判断是 Yaw 还是 Pitch —————————
static inline uint8_t IsYawMotor(void) {
    return GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)
        && GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5)
        && GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6);
}

// —— 收到完整包后的处理 —————————————————
static void Process_Packet(void) {
    // packet[] 已拆回 9 个 uint16_t
    // packet[3]=gear, 4=yaw_RC, 5=pitch_RC, 6=yaw_MPU, 7=pitch_MPU, 8=tail
    uint16_t gear = packet[3];
//    printf("%d",gear);
//    float    target;
    uint8_t  isYaw = IsYawMotor();

    // 先判断档位
    if (gear == 1792) {
        // ——— 遥控档 ———
        // Yaw 板用 yaw_RC (4)，Pitch 板用 pitch_RC (5)
        uint16_t v = isYaw ? packet[4] : packet[5];
//        printf("%d\r\n",v);
        if (v < 174)
        {
            v = 174;
//            printf("%f\r\n",target);
        }
        if (v > 1811)
        {
            v = 1811;
//            printf("%f\r\n",target);
        }
        if (v >= 992)
        {
            target = ( (v - 992) * 3.14f / (1811 - 992))+1;
//            printf("%f\r\n",target);
        }

        else
            {
            target = (-(992 - v) * 3.14f / (992 - 174))+1;
//            printf("%f\r\n",target);
            }
    }
    else if (gear == 191) {
        // ——— 自稳档 ———
        // Yaw 板用 yaw_MPU (6)，Pitch 板用 pitch_MPU (7)
        int16_t m = isYaw ? (int16_t)packet[6]
                          : (int16_t)packet[7];
        if (m >  90) m =  90;
        if (m < -90) m = -90;
        target = -m/9;
    }
    else {
        // 其他档位，直接退出
        return;
    }

    // 下发到电机驱动
}

// —— USART3 中断：字节接收 & 拆包 ——————————
void USART3_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART3_IRQHandler(void) {
//    printf("6666");
    if (USART_GetITStatus(USART3, USART_IT_RXNE)) {
        rx_buf[rx_count++] = USART_ReceiveData(USART3) & 0xFF;
        if (rx_count == PACKET_BYTES) {
            // 拆成 uint16_t 数组
            for (int i = 0; i < ELEMENTS; i++) {
                packet[i] = (uint16_t)rx_buf[2*i]
                          | (uint16_t)(rx_buf[2*i+1] << 8);
            }
            // 校验帧头/帧尾
            if (packet[0]==0x76 && packet[1]==0x54 && packet[8]==0x66) {
//                 printf("5555");
                Process_Packet();
            }
            rx_count = 0;
        }
        USART_ClearITPendingBit(USART3, USART_IT_RXNE);
    }
}

// —— USART3 + GPIO + NVIC 初始化 —————————————
void USART3_Init(void) {
    GPIO_InitTypeDef  g = {0};
    USART_InitTypeDef u = {0};
    NVIC_InitTypeDef  n = {0};

    // 时钟使能
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    // PB10=TX（备用），PB11=RX
    g.GPIO_Pin   = GPIO_Pin_10;
    g.GPIO_Mode  = GPIO_Mode_AF_PP;
    g.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &g);
    g.GPIO_Pin   = GPIO_Pin_11;
    g.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &g);

    // USART3 参数
    u.USART_BaudRate            = 115200;
    u.USART_WordLength          = USART_WordLength_8b;
    u.USART_StopBits            = USART_StopBits_1;
    u.USART_Parity              = USART_Parity_No;
    u.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    u.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;


    // 接收中断
    USART_Init(USART3, &u);
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);


    // NVIC 配置
    n.NVIC_IRQChannel                   = USART3_IRQn;
    n.NVIC_IRQChannelPreemptionPriority = 0;
    n.NVIC_IRQChannelSubPriority        = 0;
    n.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&n);

    USART_Cmd(USART3, ENABLE);
}
