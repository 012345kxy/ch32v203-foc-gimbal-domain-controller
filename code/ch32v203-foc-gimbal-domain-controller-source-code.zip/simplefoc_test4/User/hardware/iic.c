/*
 * iic.c
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

# include "iic.h"
void I2C_W_SCL(uint8_t BITVALUE)
{
    GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)BITVALUE);
    Delay_Us(5);

}

void I2C_W_SDA(uint8_t BITVALUE)
{
    GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)BITVALUE);
    Delay_Us(5);

}

uint8_t I2C_R_SDA(void)
{
    uint8_t BITVALUE;
    BITVALUE=GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7);
    Delay_Us(5);
    return BITVALUE;

}

void I2C_Init_(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
//    I2C_InitTypeDef I2C_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);//GPIOB
//    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_SetBits(GPIOB, GPIO_Pin_6|GPIO_Pin_7);

////    I2C_DeInit(I2C1);
////    I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
////    I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
////    I2C_InitStructure.I2C_OwnAddress1 = 0;     //I2C_OAR1
////    I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
////    I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
////    I2C_InitStructure.I2C_ClockSpeed = 400000;    //400KHz
////    I2C_Init(I2C1, &I2C_InitStructure);
////    I2C_Cmd(I2C1, ENABLE);
}
void I2C_Start(void)
{
    I2C_W_SDA(1);
    I2C_W_SCL(1);
    I2C_W_SDA(0);
    I2C_W_SCL(0);
}

void I2C_Stop(void)
{
    I2C_W_SDA(0);
    I2C_W_SCL(1);
    I2C_W_SDA(1);
}
void I2C_SendByte(uint8_t Byte)
{
    uint8_t i=0;
    for(i=0;i<8;i++)
    {
    I2C_W_SDA(Byte & (0x80>>i));//ȡ��byte��ÿһλ
    I2C_W_SCL(1);
    I2C_W_SCL(0);
    }

}

uint8_t I2C_ReceiveByte(void)
{
    uint8_t i,Byte = 0x00;
    I2C_W_SDA(1);
    for(i=0;i<8;i++)
    {
        I2C_W_SCL(1);
        if (I2C_R_SDA()==1){Byte|=(0x80>>i);}
        I2C_W_SCL(0);
    }
    return Byte;
}

void I2C_SendAck(uint8_t AckBit)
{
    I2C_W_SDA(AckBit);
    I2C_W_SCL(1);
    I2C_W_SCL(0);


}

uint8_t I2C_ReceiveAck(void)
{
    uint8_t AckBit;
    I2C_W_SDA(1);
    I2C_W_SCL(1);
    AckBit=I2C_R_SDA();
    I2C_W_SCL(0);
    return AckBit;
}
