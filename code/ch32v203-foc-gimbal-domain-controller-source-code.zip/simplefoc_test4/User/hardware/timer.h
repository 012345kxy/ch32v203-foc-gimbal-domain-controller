/*
 * timer.h
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

#ifndef USER_HARDWARE_TIMER_H_
#define USER_HARDWARE_TIMER_H_

#include "ch32v20x.h"

/******************************************************************************/
#define PWM_Period  1440
/******************************************************************************/
void TIM1_PWM_Init(void);
void TIM3_1ms_Init(void);
/******************************************************************************/

#endif /* USER_HARDWARE_TIMER_H_ */
