/*
 * usart.h
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */


#ifndef USER_HARDWARE_USART_H_
#define USER_HARDWARE_USART_H_

#include "stdio.h"
#include "ch32v20x.h"

#define USART_REC_LEN 256

void uart_init(unsigned long bound);

extern unsigned char USART_RX_BUF[USART_REC_LEN];
extern unsigned short USART_RX_STA;

#endif /* USER_HARDWARE_USART_H_ */
