/*
 * delay.c
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

#include "delay.h"


///******************************************************************************/
////��ʱnus
//void delay_us(unsigned long nus)
//{
//    unsigned long temp;
//
////  RCC_ClocksTypeDef clocks;
////  RCC_GetClocksFreq(&clocks);
//
//    SysTick->LOAD =nus*9;   //9=���72MHz
//    SysTick->VAL =0;
//    SysTick->CTRL =SysTick_CTRL_ENABLE_Msk;   //HCLK/8
//    do
//    {
//        temp=SysTick->CTRL;
//    }while((temp&0x01)&&!(temp&(1<<16)));
//
//    SysTick->CTRL=0;
//    SysTick->VAL =0;
//}
///******************************************************************************/
////��ʱnms
////�����ʱʱ��=0xFFFFFF/9MHz=1864ms
//void delay_ms(unsigned short nms)
//{
//    unsigned long temp;
//
//    SysTick->LOAD=(u32)nms*9000;   //9=���72MHz
//    SysTick->VAL =0;
//    SysTick->CTRL|=SysTick_CTRL_ENABLE_Msk ;  //HCLK/8
//    do
//    {
//        temp=SysTick->CTRL;
//    }while((temp&0x01)&&!(temp&(1<<16)));
//
//    SysTick->CTRL&=~SysTick_CTRL_ENABLE_Msk;
//    SysTick->VAL =0;
//}
///******************************************************************************/
////0xFFFFFF��0ѭ������
void systick_CountMode(void)//�δ�ʱ��ΪHCLK/8=72M/8=9Mhz
{
    SysTick->CMP = 0xFFFFFF-1;      //set reload register
  SysTick->CNT  = 0;
  SysTick->CTLR =  (1 << 0); //Enable SysTick Timer
}
/******************************************************************************/
