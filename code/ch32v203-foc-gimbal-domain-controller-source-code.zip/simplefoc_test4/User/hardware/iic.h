/*
 * iic.h
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

#ifndef USER_HARDWARE_IIC_H_
#define USER_HARDWARE_IIC_H_

#include "ch32v20x.h"
#include "debug.h"
/******************************************************************************/
void I2C_Init_(void);
void I2C_W_SCL(uint8_t BITVALUE);
void I2C_W_SDA(uint8_t BITVALUE);
uint8_t I2C_R_SDA(void);
void I2C_Start(void);

void I2C_Stop(void);

void I2C_SendByte(uint8_t Byte);
uint8_t I2C_ReceiveByte(void);

void I2C_SendAck(uint8_t AckBit);

uint8_t I2C_ReceiveAck(void);

/******************************************************************************/

#endif /* USER_HARDWARE_IIC_H_ */
