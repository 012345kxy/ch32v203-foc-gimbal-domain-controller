/*
 * delay.h
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

#ifndef USER_HARDWARE_DELAY_H_
#define USER_HARDWARE_DELAY_H_

#include "ch32v20x.h"

//void delay_us(unsigned long nus);
//void delay_ms(unsigned short nms);
void systick_CountMode(void);

#endif /* USER_HARDWARE_DELAY_H_ */
