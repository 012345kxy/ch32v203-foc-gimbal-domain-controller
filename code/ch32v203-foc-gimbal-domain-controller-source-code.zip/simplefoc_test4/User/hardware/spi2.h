/*
 * spi.h
 *
 *  Created on: May 14, 2025
 *      Author: 17485
 */

#ifndef USER_HARDWARE_SPI2_H_
#define USER_HARDWARE_SPI2_H_

#include "ch32v20x.h"
/******************************************************************************/
void SPI2_Init_(void);
/******************************************************************************/

#endif /* USER_HARDWARE_SPI2_H_ */
