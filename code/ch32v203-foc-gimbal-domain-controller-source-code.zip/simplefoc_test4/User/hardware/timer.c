/*
 * timer.c
 *
 *  Created on: May 13, 2025
 *      Author: 17485
 */

#include "ch32v20x.h"
#include "timer.h"



void TIM1_PWM_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    TIM_TimeBaseInitTypeDef   TIM_TimeBaseInitStructure={0};
    TIM_OCInitTypeDef         TIM_OCInitStructure={0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    TIM_DeInit(TIM1);
    TIM_TimeBaseInitStructure.TIM_Prescaler=0;
    TIM_TimeBaseInitStructure.TIM_Period=1440-1;  //25KHz =72M/1440/2
    TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_CenterAligned1;
    TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStructure);

    TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse=0;
    TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;
    TIM_OC1Init(TIM1,&TIM_OCInitStructure);
    TIM_OC2Init(TIM1,&TIM_OCInitStructure);
    TIM_OC3Init(TIM1,&TIM_OCInitStructure);
    TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM1,TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM1,TIM_OCPreload_Enable);

    TIM_ARRPreloadConfig(TIM1,ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_Cmd(TIM1,ENABLE);


//    GPIO_InitTypeDef GPIO_InitStructure;
//        TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
//        TIM_OCInitTypeDef TIM_OCInitStructure;
//
//        // 1. ʱ������
//        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
//        RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
//
//        // 2. GPIO���ã�ȷ��CH32�ĸ���ģʽ��
//        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
//        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  // ��CH32ר��ģʽ
//        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//        GPIO_Init(GPIOA, &GPIO_InitStructure);
//
//        // 3. ��ʱ����������
//        TIM_DeInit(TIM1);
//        TIM_TimeBaseInitStructure.TIM_Prescaler = 0;      // 72MHz����
//        TIM_TimeBaseInitStructure.TIM_Period = 1440-1;    // 25kHz�����Ķ��룩
//        TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_CenterAligned1;
//        TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//        TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStructure);
//
//        // 4. PWM�������
//        TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
//        TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
//        TIM_OCInitStructure.TIM_Pulse = 720;              // 50%ռ�ձ�
//        TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
//        TIM_OC1Init(TIM1, &TIM_OCInitStructure);
//        TIM_OC2Init(TIM1, &TIM_OCInitStructure);
//        TIM_OC3Init(TIM1, &TIM_OCInitStructure);
//
//        // 5. Ԥװ�غ�ʹ��
//        TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
//        TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
//        TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
//        TIM_ARRPreloadConfig(TIM1, ENABLE);
//
//        // 6. �߼���ʱ����������MOE
//        TIM_CtrlPWMOutputs(TIM1, ENABLE);
//        TIM_Cmd(TIM1, ENABLE);
}
///***************************************************************************/
void TIM3_1ms_Init(void)  //(u16 arr,u16 psc)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_TimeBaseInitStructure.TIM_Period = 1000-1;      //1ms
    TIM_TimeBaseInitStructure.TIM_Prescaler=72-1;       //72��Ƶ=1MHz
    TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);
    TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
    TIM_Cmd(TIM3,ENABLE);
}
/***************************************************************************/
/***************************************************************************/
