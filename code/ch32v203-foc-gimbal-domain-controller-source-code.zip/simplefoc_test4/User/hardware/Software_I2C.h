/*
 * Software_I2C.h
 *
 *  Created on: May 20, 2025
 *      Author: 17485
 */

#ifndef USER_AS5600_SOFTWARE_I2C_H_
#define USER_AS5600_SOFTWARE_I2C_H_

#include "debug.h"
#include "ch32v20x_gpio.h"
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2))
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr))
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum))


#define IIC_SCL_Pin         GPIO_Pin_6
#define IIC_SCL_GPIO_Port   GPIOB
#define IIC_SDA_Pin         GPIO_Pin_7
#define IIC_SDA_GPIO_Port   GPIOB


#define SCL_H         GPIO_WriteBit(IIC_SCL_GPIO_Port,IIC_SCL_Pin,1)
#define SCL_L         GPIO_WriteBit(IIC_SCL_GPIO_Port,IIC_SCL_Pin,0)

#define SDA_H         GPIO_WriteBit(IIC_SDA_GPIO_Port,IIC_SDA_Pin,1)
#define SDA_L         GPIO_WriteBit(IIC_SDA_GPIO_Port,IIC_SDA_Pin,0)

#define SCL_read      GPIO_ReadInputDataBit(IIC_SCL_GPIO_Port,IIC_SCL_Pin)
#define SDA_read      GPIO_ReadInputDataBit(IIC_SDA_GPIO_Port,IIC_SDA_Pin)

void IIC_GPIO_Init(void);
uint8_t SW_IIC_Start(void);
void SW_IIC_Stop(void);
uint8_t SW_IIC_Wait_Ack(void);
void SW_IIC_Ack(void);
void SW_IIC_NAck(void);
unsigned char SW_IIC_Read_Byte(void);
void SW_IIC_Send_Byte(uint8_t SendByte);


extern unsigned char SW_IIC_ReadOneByte(unsigned char I2C_Addr,unsigned char addr);
extern unsigned char SW_IICwriteByte(unsigned char dev, unsigned char reg, unsigned char data);
extern uint8_t SW_IICwriteBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data);
extern uint8_t SW_IICwriteBit(uint8_t dev,uint8_t reg,uint8_t bitNum,uint8_t data);
extern uint8_t SW_IICreadBytes(uint8_t SlaveAddress,uint8_t REG_Address,uint8_t len,uint8_t *data);


#endif /* USER_AS5600_SOFTWARE_I2C_H_ */
